<?php
defined('_JEXEC') or die;
?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <jdoc:include type="head" />
  <link rel="stylesheet" href="css/template.css" type="text/css" />
  <link rel="stylesheet" href="css/custom.css">
</head>
<body>
  <div class="header">
    <h1>Світ Рослин</h1>
    <p>Все про кімнатні та садові рослини</p>
  </div>
  <div class="menu">
    <jdoc:include type="modules" name="menu" style="none" />
  </div>
  <div class="hero"><h2>Ласкаво просимо до світу рослин!</h2></div>
  <div class="content">
    <jdoc:include type="modules" name="cards" />
    <jdoc:include type="component" />
  </div>
  <div class="footer">
    <p>&copy; 2025 Світ Рослин. Всі права захищено.</p>
  </div>
</body>
</html>
