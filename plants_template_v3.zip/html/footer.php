<?php
defined('_JEXEC') or die;
?>
<footer>
  <p>Контакти: info@plants.ua | +38 (044) 123-45-67</p>
</footer>
