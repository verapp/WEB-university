<?php
defined('_JEXEC') or die;
?>
<div class="sidebar">
  <h2>Корисні статті</h2>
  <ul>
    <li><a href="#">Як доглядати за орхідеями</a></li>
    <li><a href="#">Топ-10 кімнатних рослин</a></li>
    <li><a href="#">Секрети успішного садівництва</a></li>
  </ul>
</div>
